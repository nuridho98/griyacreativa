# WhatsApp Web Wrapper untuk Android 6.0 (API 23)

Aplikasi native Android berbasis Java yang membungkus WhatsApp Web (`https://web.whatsapp.com/`) ke dalam WebView layar penuh dengan fitur lengkap untuk kompatibilitas optimal pada perangkat Android lawas (Android 6.0 Marshmallow, API 23) hingga Android modern.

---

## 📋 Fitur & Pemenuhan Syarat

1. **Kompatibilitas SDK:**
   - `minSdkVersion 23` (Android 6.0 Marshmallow)
   - `targetSdkVersion 28` (Android 9.0 Pie) - Menghindari batasan scoped storage dan kebijakan restriktif Android terbaru.
2. **WebView Fullscreen & Konfigurasi Engine:**
   - `JavaScript` aktif (`setJavaScriptEnabled(true)`)
   - `DOM Storage` aktif (`setDomStorageEnabled(true)`)
   - `Database & AppCache` aktif
   - Mode layar penuh tanpa ActionBar (`Theme.NoActionBar` + `FLAG_FULLSCREEN`)
3. **Custom User-Agent:**
   - Dilengkapi User-Agent **Chrome Desktop** (`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ...`).
   - *Catatan Teknis:* Server WhatsApp Web secara default menolak dan mengalihkan peramban mobile ke `whatsapp.com`. Dengan Desktop UA, QR code WhatsApp Web akan tampil dengan sempurna.
4. **Runtime Permissions (Android 6+ API 23):**
   - Penanganan runtime dialog untuk:
     - `CAMERA` (kamera)
     - `RECORD_AUDIO` (voice note & telepon)
     - `WRITE_EXTERNAL_STORAGE` & `READ_EXTERNAL_STORAGE` (kirim & simpan foto/file)
   - Penanganan `WebChromeClient.onPermissionRequest` untuk WebRTC browser.
5. **WebChromeClient onShowFileChooser:**
   - Mendukung tag `<input type="file">` pada WhatsApp Web.
   - Terintegrasi dengan `FileProvider` untuk mengambil foto langsung dari Kamera atau memilih berkas dari Galeri / Penyimpanan.
6. **onBackPressed Navigation:**
   - Tombol back fisik/layar memeriksa `webView.canGoBack()`. Jika ada riwayat (misal dari chat ke daftar obrolan), WebView akan mundur alih-alih langsung menutup aplikasi.
7. **Persistent Cookies (Anti-Logout):**
   - `CookieManager.getInstance().setAcceptCookie(true)`
   - `CookieManager.getInstance().setAcceptThirdPartyCookies(mWebView, true)`
   - Pemanggilan `flush()` saat `onPageFinished` dan `onPause` agar sesi login tetap tersimpan di memori lokal bahkan setelah aplikasi ditutup atau HP di-restart.
8. **Splash Screen Sederhana:**
   - `SplashActivity` dengan warna khas WhatsApp (`#075E54`), logo vektor, dan transisi halus setelah 1.5 detik.

---

## 🚀 Cara Membuka di Android Studio

1. **Unduh Berkas Proyek:**
   - Klik tombol **"Unduh Proyek (.ZIP)"** pada aplikasi ini.
   - Ekstrak berkas ZIP ke folder komputer Anda (misal `C:\AndroidProjects\WAWebWrapper`).

2. **Buka di Android Studio:**
   - Buka Android Studio (versi Flamingo, Giraffe, Iguana, Koala, atau yang lebih baru).
   - Pilih **File > Open**, lalu arahkan ke folder yang diekstrak.
   - Tunggu Gradle Sync selesai (pastikan koneksi internet aktif untuk mengunduh dependencies).

3. **Jalankan Aplikasi:**
   - Hubungkan HP Android 6.0+ via kabel USB (USB Debugging aktif) atau gunakan Android Virtual Device (AVD).
   - Klik tombol **Run (Segitiga Hijau)** di Android Studio.
